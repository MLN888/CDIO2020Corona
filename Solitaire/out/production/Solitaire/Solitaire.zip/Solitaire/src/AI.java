import java.util.ArrayList;

public class AI {

    /*  The AI receives the ArrayList with legal move objects.
    *   The AI selects the best move.
    *   The AI prints to console what the best move is
    *   The AI updates Table to reflect the move (assuming that the player performs move correctly)
    *   When player wins or loses, game is stopped by setting Table.gameOn = false.
    * */

    public void thinkHard(ArrayList legalMoves) {
        // artificial intelligence
        // neural network
        // machine learning
        // big data
        // HPC multi threaded cluster via thinlinc
    }

}
