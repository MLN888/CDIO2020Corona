import java.util.ArrayList;
import java.util.List;

public class Table {

    // This variable is only null until the class is instantiated for the first time
    private static Table singleInstance = null;

    // The twelve positions of the solitaire table. The variable is STATIC and can be accessed from all other classes
    public static List<List<String>> position;
    /*
        Positions 0-6:    Columns
        Positions 7-10:   Foundation piles
        Positions 11:     Draw pile
    */

    public static boolean debugText;        // Boolean to switch debug printouts on/off
    public static boolean gameOn = true;    // When true, game continues indefinitely.

    // Constructor. It is private, so the Table class can only be instantiated from inside this class.
    private Table() {
        position = new ArrayList<>();             // The 'outer' ArrayList is initialized

        for (int i = 0; i < 12; i++) {
            position.add(new ArrayList<>());      // The 12 'inner' ArrayLists are added
        }

        for (int i = 0; i < 7; i++) {
            position.get(i).add("XX");            // An "XX" is added to each column, denoting no cards
        }

        position.get(7).add("XC");                // Foundation pile 1 is marked with clubs. X means no card.
        position.get(8).add("XD");                // Foundation pile 2 is marked with diamonds. X means no card.
        position.get(9).add("XH");                // Foundation pile 3 is marked with hearts. X means no card.
        position.get(10).add("XS");               // Foundation pile 4 is marked with spades. X means no card.

        position.get(11).add("XX");               // Draw pile is also initialized with "XX", denoting no card
    }

    // The following method is the essence of a so called "singleton" class.
    // When this public method is called for the first time, the Table Class is instantiated in
    // the variable "singleInstance". If called a second time, it only returns itself.
    public static Table createTable() {
        if (singleInstance == null) {           // This only happens the first time method is called
            singleInstance = new Table();
        }
        return singleInstance;
    }

    public static void printTable() {
        System.out.println();
        System.out.println("******* CURRENT TABLE *******");
        System.out.println("Draw pile: " + Table.position.get(11).get(1));      // Print drawpile. There is always only 1 card here

        for (int i = 7; i < 11; i++) {                                   // Iterate foundation piles (positions 7-10)
            System.out.print("Foundation " + (i - 6) + ": ");
            for (int j = 0; j < Table.position.get(i).size(); j++) {
                System.out.print(Table.position.get(i).get(j) + " ");
            }
            System.out.println();
        }

        for (int i = 0; i < 7; i++) {                                   // Iterate columns (positions 0-6)
            System.out.print("Column " + i + ": ");
            for (int j = 0; j < Table.position.get(i).size(); j++) {
                System.out.print(Table.position.get(i).get(j) + " ");
            }
            System.out.println();
        }
        System.out.println("******* TABLE END *******\n");
    }
}
