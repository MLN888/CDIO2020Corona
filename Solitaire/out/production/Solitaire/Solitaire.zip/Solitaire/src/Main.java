import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Table.createTable();        // Instantiates the Table. This is the primary data structure of the game board. Only one instance can exist.
        Table.debugText = true;     // Sets if you want various debug print-outs to be displayed
        ArrayList<Move> legalMoves;
        FindLegalMoves findLegalMoves = new FindLegalMoves();   // New findLegalMoves object.


        FileHandler fileHandler = new FileHandler();    // Create FileHandler

        while (Table.gameOn) {                          // Game loops while 'gameOn' is true
            fileHandler.updateTable();                  // This method reads file and updates Table

            legalMoves= findLegalMoves.findMoves();

            Selection();
        }
    }

    // Method to stay in game loop. This is for testing. In the finished version, AI will handle talking to player
    private static void Selection() {
        System.out.println("\nEnter something to go again.\nEnter 'e' to exit.");
        Scanner myScanner = new Scanner(System.in);
        String input = myScanner.nextLine();
        if (input.equals("e")) {
            Table.gameOn = false;
        }
    }
}
