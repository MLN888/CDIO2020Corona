public class Move {

    private int fromPosition;   // Which column (or draw pile) can we move something from
    private int toPosition;     // Which column or foundation pile can we move something to
    private int cut;            // Where to cut the column when moving a group of cards. 1 = top card
    private int type;           // What type of move we are talking about
    // Type 1 : move card from a column or the draw pile to a foundation pile
    // Type 2 : move one or more cards from a column to a column
    // Type 3 : move a king from a column or the draw pile to an empty column
    // Type 4 : move the card from the draw pile to a column


    public Move(int fromColumn, int toPosition, int cut, int type) {
        this.fromPosition = fromColumn;
        this.toPosition = toPosition;
        this.cut = cut;
        this.type = type;
    }

    public int getFromPosition() {
        return fromPosition;
    }

    public int getToPosition() {
        return toPosition;
    }

    public int getCut() {
        return cut;
    }

    public int getType() {
        return type;
    }

    @Override               // OMG the toString method is overwritten. Amazing Java skills.
    public String toString() {
        return "Move{" +
                "fromPosition=" + fromPosition +
                ", toColumn=" + toPosition +
                ", cut=" + cut +
                ", type=" + type +
                '}';
    }
}
