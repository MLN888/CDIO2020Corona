import java.util.ArrayList;

public class FindLegalMoves {

    ArrayList<Move> allMoves;

    public FindLegalMoves() {
        this.allMoves = new ArrayList<>();
    }

    public ArrayList<Move> findMoves() {
        allMoves.clear();
        checkFoundations();
        // checkColumns();
        // checkDrawPile();
        // checkKingToFreeSpot();

        if (Table.debugText) {      // Print out all move-objects from the allMove ArrayList.
            System.out.println("\n******* POSSIBLE MOVES FOUND *******");
            for (int i = 0; i < allMoves.size(); i++) {
                System.out.println(allMoves.get(i).toString());
            }
        }
        return allMoves;
    }

    private void checkFoundations() {

        if (Table.debugText) System.out.println("******* CHECK FOUNDATIONS *******");
        for (int i = 0; i < 7; i++) { // Iterate columns
            int valueColumnCard = extractValue(Table.position.get(i).get(Table.position.get(i).size() - 1));    // get value
            String suitColumnCard = Table.position.get(i).get(Table.position.get(i).size() - 1).substring(1);   // get suit
            if (Table.debugText)
                System.out.println("(column " + i + ")   Value of card: " + valueColumnCard + "   Suit of card: " + suitColumnCard);

            for (int j = 7; j < 11; j++) { // Iterate foundation piles
                int valueFoundationCard = extractValue(Table.position.get(j).get(Table.position.get(j).size() - 1));    // get value
                String suitFoundationCard = Table.position.get(j).get(Table.position.get(j).size() - 1).substring(1);   // get suit
                if (Table.debugText)
                    System.out.println("(foundation " + (j - 6) + ")   Value of card: " + valueFoundationCard + "   Suit of card: " + suitFoundationCard);

                // Check if top card of a column can be placed on a foundation pile by comparing values and suits.
                if (valueColumnCard == valueFoundationCard + 1 && (suitColumnCard.equals(suitFoundationCard) || suitFoundationCard.equals("X"))) {
                    if (Table.debugText)
                        System.out.println("Match column " + i + " to foundation " + (j - 6));      // If match
                    Move move = new Move(i, j, Table.position.get(i).size() - 1, 1);    // Create Move object
                    allMoves.add(move);     // Add the new legal move to ArrayList of legal moves
                }
            }
        }

        // Now we check if the draw pile holds a card that can be moved to a foundation pile
        int valueDrawPile = extractValue(Table.position.get(11).get(Table.position.get(11).size() - 1));        // get value
        String suitDrawPile = Table.position.get(11).get(Table.position.get(11).size() - 1).substring(1);     // get suit
        for (int i = 7; i < 11; i++) {         // Iterate foundation piles
            int valueFoundationCard = extractValue(Table.position.get(i).get(Table.position.get(i).size() - 1));    // get value
            String suitFoundationCard = Table.position.get(i).get(Table.position.get(i).size() - 1).substring(1);   // get suit
            if (valueDrawPile == valueFoundationCard + 1 && (suitDrawPile.equals(suitFoundationCard) || suitFoundationCard.equals("X"))) {
                if (Table.debugText) System.out.println("\nDraw pile: Match to foundation " + (i - 6));
                Move move = new Move(11, i, 1, 1);
                allMoves.add(move);
            }
        }
        if (Table.debugText) System.out.println("******* FOUNDATIONS CHECKED ******");
    }

    private int extractValue(String card) {
        // Checks first character in a card-String and returns the value as an integer 1-13
        int value = 0;
        String firstCharacter = card.substring(0, 1);
        switch (firstCharacter) {
            case "A":
                value = 1;
                break;
            case "0":
                value = 10;
                break;
            case "J":
                value = 11;
                break;
            case "Q":
                value = 12;
                break;
            case "K":
                value = 13;
                break;
            case "X":
                value = 0;
                break;
            default:
                try {
                    value = Integer.parseInt(firstCharacter);
                } catch (NumberFormatException e) {
                    System.out.println("Error extacting value from card");
                    return -1;
                }
                return value;
        }
        return value;
    }
}
